<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="electivas.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Electivas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="notas.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                notas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="promedios.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Promedios
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="materias.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                materias
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="carreras.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                carreras
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="persentiles.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                persentil
              </a>
            </li>
          </ul>